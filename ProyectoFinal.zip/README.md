### para transpilar con babel:

```
npm run ServerES6toJS5

```

### con TS:

```
npm run ServerTStoJS5

```

### start

```
npm run start

```
